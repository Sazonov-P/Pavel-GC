﻿namespace TaskApi.Models
{
    public class TaskItem
    {
        public long Id { get; set; }
        public string TaskName { get; set; }
        public string Content { get; set; }
        public string DueTo { get; set; }
        public string Owner { get; set; }
        public bool IsComplete { get; set; }
    }
}
